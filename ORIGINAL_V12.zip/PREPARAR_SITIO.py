#!/usr/bin/env python3
"""Arma el sitio estático completo descargando SOLO motor libre y Freedoom oficial.
Necesita internet únicamente en equipo de publicación (CI), no en dispositivos de jugadores.
"""
from pathlib import Path
from urllib.request import Request,urlopen
import tempfile, zipfile, shutil, hashlib, sys
ROOT=Path(__file__).resolve().parent
ENGINE='https://github.com/danborden1/doom-web/archive/refs/heads/main.zip'
DATA='https://github.com/freedoom/freedoom/releases/download/v0.13.0/freedoom-0.13.0.zip'

def get(url,dest):
    print('Obteniendo:',url,flush=True)
    with urlopen(Request(url, headers={'User-Agent':'ArcadeExcelV12/1.0'}), timeout=180) as source,open(dest,'wb') as out:
        shutil.copyfileobj(source,out)
    if dest.stat().st_size < 1024: raise RuntimeError('Descarga incompleta: '+url)

def safe_extract(zf,dest):
    for item in zf.infolist():
        resolved=(dest/item.filename).resolve()
        if not resolved.is_relative_to(dest.resolve()):raise RuntimeError('Ruta insegura en ZIP')
    zf.extractall(dest)

def iwad_check(file):
    if file.stat().st_size < 10_000_000:raise RuntimeError('IWAD demasiado pequeño')
    with file.open('rb') as f:
        if f.read(4)!=b'IWAD':raise RuntimeError('IWAD inválido')

with tempfile.TemporaryDirectory() as d:
    temp=Path(d); get(ENGINE,temp/'engine.zip');get(DATA,temp/'freedoom.zip')
    with zipfile.ZipFile(temp/'engine.zip') as z:safe_extract(z,temp/'engine')
    with zipfile.ZipFile(temp/'freedoom.zip') as z:safe_extract(z,temp/'data')
    eng=temp/'engine'/'doom-web-main'
    required=['index.html','websockets-doom.js','websockets-doom.wasm','COPYING','FREEDOOM-COPYING.txt','FREEDOOM-CREDITS.txt']
    for name in required:
        if not (eng/name).is_file():raise RuntimeError('No se encontró archivo del motor '+name)
    wads={name: list((temp/'data').rglob(name)) for name in ('freedoom1.wad','freedoom2.wad')}
    for name,files in wads.items():
        if len(files)!=1:raise RuntimeError('WAD ausente o duplicado: '+name)
        iwad_check(files[0])
    original=(eng/'index.html').read_text(encoding='utf-8')
    if 'freedoom1.wad' not in original:raise RuntimeError('La plantilla del motor cambió; revisar antes de continuar')
    for i in (1,2):
        target=ROOT/'juegos'/('freedoom' if i==1 else 'freedoom2')
        target.mkdir(parents=True,exist_ok=True)
        for f in required+['default.cfg']:
            if (eng/f).is_file():shutil.copy2(eng/f,target/f)
        name=f'freedoom{i}.wad'
        shutil.copy2(wads[name][0],target/name)
        if i==2:
            (target/'index.html').write_text(original.replace('freedoom1.wad','freedoom2.wad'),encoding='utf-8')
        print('Preparado:',name,'bytes:',(target/name).stat().st_size,flush=True)
print('V12 empaquetada; lista para desplegar como sitio estático.',flush=True)
